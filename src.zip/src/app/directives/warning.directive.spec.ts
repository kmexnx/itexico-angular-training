import { WarningDirective } from './warning.directive';

describe('WarningDirective', () => {
  it('should create an instance', () => {
    const directive = new WarningDirective();
    expect(directive).toBeTruthy();
  });
});
